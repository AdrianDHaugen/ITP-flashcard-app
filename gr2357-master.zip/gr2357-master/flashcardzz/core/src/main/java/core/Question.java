package core;

public abstract class Question {
    final static int MULTIPLE_CHOICE = 0;

    public abstract int getQuestionType();
}
